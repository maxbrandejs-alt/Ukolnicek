# Úkolníček pro Android – zdarma, bez karty

Aplikace běží v telefonu úplně offline. Upozornění přijdou jako normální
oznámení, i když je aplikace zavřená. Sdílené skupiny jsou v online verzi na claude.ai
(odkaz je v aplikaci v levém menu).

Instalační soubor (.apk) ti zdarma sestaví **GitHub**. Nepotřebuješ kartu
ani nic instalovat do počítače, stačí prohlížeč. Celé to zabere asi 10 minut.

## 1. Založ si účet na GitHubu

Jdi na **github.com** → **Sign up**. Stačí e-mail a heslo, karta se nezadává.

## 2. Vytvoř úložiště (repozitář)

1. Vpravo nahoře **+** → **New repository**.
2. Název třeba `ukolnicek`, nech **Public** a klikni **Create repository**.

## 3. Nahraj projekt

1. Na stránce nového úložiště klikni na odkaz **uploading an existing file**.
2. Otevři rozbalenou složku **Ukolnicek-Android**, označ **všechno, co je uvnitř**
   (složky `app`, `gradle` a soubory `build.gradle`, `settings.gradle`, …)
   a přetáhni to do okna prohlížeče.
3. Dole klikni **Commit changes**.

## 4. Zapni sestavení

Složka `.github` se při přetahování často nenahraje (je skrytá), proto ji vytvoř ručně:

1. V úložišti klikni **Add file** → **Create new file**.
2. Do pole s názvem napiš přesně: `.github/workflows/build.yml`
3. Do velkého pole vlož celý obsah souboru **build-github.yml** (je v této složce,
   otevři ho v Poznámkovém bloku, označ vše a zkopíruj).
4. Klikni **Commit changes** a ještě jednou **Commit changes**.

## 5. Stáhni hotovou aplikaci

1. Nahoře klikni na záložku **Actions**. Uvidíš běžící „Sestavit aplikaci“
   (žlutý kroužek). Za 3–5 minut se změní na zelenou fajfku.
2. Klikni na něj a dole v části **Artifacts** stáhni **Ukolnicek-aplikace**.
3. Stáhne se zip, uvnitř je **Ukolnicek.apk**.

Celé to jde udělat i rovnou v telefonu v prohlížeči. Kroky 1–4 jsou ale pohodlnější
na počítači.

## 6. Nainstaluj do telefonu

1. Pošli si `Ukolnicek.apk` do telefonu (nebo ho tam rovnou stáhni) a otevři ho.
2. Android se zeptá, jestli povolit instalaci z neznámých zdrojů. Povol to.
3. Nainstaluj, spusť a **povol oznámení**, jinak upozornění nechodí.

## Dobré vědět

- **Data jsou jen v telefonu.** Když aplikaci odinstaluješ, úkoly se smažou.
- **Aktualizace:** novou verzi stačí nainstalovat přes starou, data zůstanou.
  Aplikace je pokaždé podepsaná stejným klíčem (`app/ukolnicek.keystore`).
- Úložiště na GitHubu obsahuje jen kód aplikace, **ne tvoje úkoly**.
- Některé telefony (Xiaomi, Huawei, Samsung s úsporou baterie) brzdí aplikace
  na pozadí. Když upozornění chodí pozdě, vypni pro Úkolníček optimalizaci baterie.

## Druhá možnost: Android Studio

Android Studio je také zdarma a kartu nechce (stahuj ho z developer.android.com/studio,
ne z Google Play Console). Otevři v něm složku Ukolnicek-Android a zvol
**Build → Build APK(s)**.
