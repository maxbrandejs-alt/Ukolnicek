package cz.ukolnicek.app;

import android.content.Context;
import android.webkit.JavascriptInterface;

/** Called from the page as window.UkolnicekAndroid. */
public class Bridge {

    private final Context ctx;

    Bridge(Context context) {
        ctx = context.getApplicationContext();
    }

    /** Replaces all scheduled reminders. json = [{id, at (ms), title, body}, ...] */
    @JavascriptInterface
    public void setReminders(String json) {
        Reminders.replaceAll(ctx, json);
    }
}
