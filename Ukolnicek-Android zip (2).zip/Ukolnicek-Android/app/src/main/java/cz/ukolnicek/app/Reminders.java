package cz.ukolnicek.app;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** Schedules phone notifications with AlarmManager, so they arrive even when the app is closed. */
final class Reminders {

    static final String CHANNEL = "reminders";
    private static final String PREFS = "reminders";
    private static final String KEY = "list";

    private Reminders() {
    }

    static void ensureChannel(Context ctx) {
        NotificationManager nm = ctx.getSystemService(NotificationManager.class);
        if (nm == null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Připomenutí úkolů", NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("Upozornění na úkoly a denní úkoly");
        nm.createNotificationChannel(ch);
    }

    static synchronized void replaceAll(Context ctx, String json) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        JSONArray old = parse(prefs.getString(KEY, "[]"));
        for (int i = 0; i < old.length(); i++) {
            JSONObject o = old.optJSONObject(i);
            if (o != null) cancel(ctx, o.optString("id"));
        }
        JSONArray list = parse(json);
        prefs.edit().putString(KEY, list.toString()).apply();
        scheduleAll(ctx, list);
    }

    /** After a phone restart all alarms are gone, so BootReceiver schedules them again. */
    static void restore(Context ctx) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        scheduleAll(ctx, parse(prefs.getString(KEY, "[]")));
    }

    private static JSONArray parse(String json) {
        try {
            return new JSONArray(json == null ? "[]" : json);
        } catch (JSONException e) {
            return new JSONArray();
        }
    }

    private static void scheduleAll(Context ctx, JSONArray list) {
        long now = System.currentTimeMillis();
        for (int i = 0; i < list.length(); i++) {
            JSONObject o = list.optJSONObject(i);
            if (o == null) continue;
            long at = o.optLong("at", 0);
            if (at <= now) continue;
            schedule(ctx, o.optString("id"), at, o.optString("title"), o.optString("body"));
        }
    }

    private static PendingIntent intentFor(Context ctx, String id, String title, String body) {
        Intent i = new Intent(ctx, ReminderReceiver.class);
        i.setAction("cz.ukolnicek.app.REMIND." + id);
        i.putExtra("id", id);
        i.putExtra("title", title);
        i.putExtra("body", body);
        return PendingIntent.getBroadcast(ctx, id.hashCode(), i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static void schedule(Context ctx, String id, long at, String title, String body) {
        AlarmManager am = ctx.getSystemService(AlarmManager.class);
        if (am == null) return;
        PendingIntent pi = intentFor(ctx, id, title, body);
        boolean exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
        try {
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        }
    }

    private static void cancel(Context ctx, String id) {
        AlarmManager am = ctx.getSystemService(AlarmManager.class);
        if (am == null || id == null || id.isEmpty()) return;
        am.cancel(intentFor(ctx, id, "", ""));
    }
}
